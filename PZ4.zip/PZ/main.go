package main

import (
	"fmt"
	"net/http"
	"sync"
	"time"
)

func worker(id int, jobs <-chan int, result chan<- int) {
	for j := range jobs {
		fmt.Printf("Воркер %d начал обработку задачи %d\n", id, j)
		result <- j * j
		fmt.Printf("Воркер %d завершил обработку задачи %d\n", id, j)
	}
}

func main() {

	fmt.Println("------------------------------------------------------ Задача 1 ------------------------------------------------------")

	var jo sync.WaitGroup

	jo.Add(1)

	go func() {

		defer jo.Done()

		for i := 1; i <= 5; i++ {
			fmt.Println(i)
			time.Sleep(1 * time.Second)
		}
	}()

	jo.Wait()

	fmt.Println("Горутина end")

	fmt.Println("------------------------------------------------------ Задача 2 ------------------------------------------------------")

	result := make(chan int, 10)
	jobs := make(chan int, 10)

	for x := 1; x <= 3; x++ {
		go worker(x, jobs, result)
	}

	for j := 1; j <= 10; j++ {
		jobs <- j
	}
	close(jobs)

	for r := 1; r <= 10; r++ {
		fmt.Println("Результат:", <-result)
	}

	fmt.Println("------------------------------------------------------ Задача 3 ------------------------------------------------------")

	sem := make(chan struct{}, 5)

	tick := time.Tick(200 * time.Millisecond)

	for i := 1; i <= 15; i++ {
		go func() {
			sem <- struct{}{}
		}()
		defer func() { <-sem }()

		fmt.Println("Обрабатываем запрос под номером ____", i)
		<-tick
	}

	fmt.Println("------------------------------------------------------ Задача 4 ------------------------------------------------------")

	sem1 := make(chan struct{}, 3)

	var urls = []string{"https://google.com/", "https://soundcloud.com/", "https://x.com/", "https://youtube.com/", "https://pinterest.com", "https://ozon.ru"}

	var wg sync.WaitGroup

	for _, url := range urls {
		wg.Add(1)
		go func() {
			sem1 <- struct{}{}
			defer func() { <-sem1; wg.Done() }()
			r, err := http.Get(url)
			if err != nil {
				fmt.Println(err)
				return
			}
			fmt.Printf("%v STATUS %v\n", url, r.Status)
		}()
	}
	wg.Wait()

}
